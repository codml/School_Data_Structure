#include "Manager.h"

int main() // main function
{
	Manager manager;
	manager.run("command.txt");

	return 0;
}
